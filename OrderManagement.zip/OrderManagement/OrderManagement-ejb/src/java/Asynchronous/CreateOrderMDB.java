/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Asynchronous;

import OrderManagementEntity.CustomerOrder;
import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.ejb.MessageDrivenContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

/**
 *
 * @author Research
 */
@MessageDriven(mappedName = "jms/CreateOrderMDB", activationConfig = {
    //@ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge"),
    @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue")
})
public class CreateOrderMDB implements MessageListener {

    @Resource
    private MessageDrivenContext messageDrivenContext;

    @Resource
    UserTransaction utx;
        
    @PersistenceContext(unitName = "OrderManagement-ejbPU")
    private EntityManager entityManager;
    
    public CreateOrderMDB() {
    }
    
    public void create(Object object) {
        entityManager.persist(object);
    }
    
    /**
     * Create New Orders + persistent database  
     * @param message
     */
    @Override
    public void onMessage(Message message) {
        ObjectMessage msg;
        try {
            if (message instanceof ObjectMessage) {
                msg = (ObjectMessage) message;
                CustomerOrder customerOrder;
                customerOrder = (CustomerOrder) msg.getObject();
                create(customerOrder);            
            }
        } catch (JMSException e) {
            messageDrivenContext.setRollbackOnly();
        } catch (Throwable te) {
        }
    }
}
