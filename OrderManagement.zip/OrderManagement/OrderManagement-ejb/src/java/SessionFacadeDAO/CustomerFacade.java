/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SessionFacadeDAO;

import CustomerManagementEntity.Customer;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Research
 */
@Stateless
public class CustomerFacade extends AbstractFacade<Customer> {
    
    @PersistenceContext(unitName = "OrderManagement-ejbPU")
    private EntityManager entityManager;
    /**
     * R1: AbstractFacade implementation allows user management(Add, Edit, Remove).
     */
    public CustomerFacade() {
        super(Customer.class);
    }
    /**
     * getEntityManager()
     * @return injected EntityManager
     */
    @Override
    protected EntityManager getEntityManager() {
        return entityManager;
    }
}
