/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SessionFacadeDAO;

import OrderManagementEntity.CustomerOrder;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Research
 */
@Stateless
public class CustomerOrderFacade extends AbstractFacade<CustomerOrder> {

    @PersistenceContext(unitName = "OrderManagement-ejbPU")
    private EntityManager entityManager;

    public CustomerOrderFacade() {
        super(CustomerOrder.class);
    }
    
    /**
     * getEntityManager()
     * @return injected EntityManager
     */
    @Override
    protected EntityManager getEntityManager() {
        return entityManager;
    }
    /**
     * R3: Application does not allow users to remove orders.
     * @param entity : CustomerOrder
     */
    @Override
    public void remove(CustomerOrder entity) {
    }
    /**
     * R4: Order Creations must be Asynchronous
     * @param entity : CustomerOrder
     */
    @Override
    public void create(CustomerOrder entity) {
    }
}
