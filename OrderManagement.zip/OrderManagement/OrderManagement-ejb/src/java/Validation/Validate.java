/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Validation;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Research
 */
public class Validate {
    private static final String DATE_FORMAT = "yyyy-MM-dd";
 
    public static boolean validDate(Date dueDate){
        String dateToValidate = dueDate.toString();
        if(dateToValidate == null){
                return false;
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_FORMAT);
        simpleDateFormat.setLenient(false);
        try {
            //if not valid, it will throw ParseException
            Date date = simpleDateFormat.parse(dateToValidate);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    public static boolean validCurrency(BigDecimal amount) {
        Pattern p=Pattern.compile("^(?:0|[1-9]\\d{0,2}(?:\\.\\d{3})*),\\d{2}$");
        Matcher m=p.matcher(amount.toString());
        return m.matches();
    }
}
