/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import CustomerManagementEntity.Customer;
import static HTMLCreation.HTML.htmlFooterSection;
import static HTMLCreation.HTML.htmlHeaderSection;
import static HTMLCreation.PopUp.displayAlert;
import static HTMLCreation.PopUp.updateAlert;
import OrderManagementEntity.CustomerOrder;
import SessionFacadeDAO.CustomerFacade;
import SessionFacadeDAO.CustomerOrderFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Research
 */
@WebServlet(name = "ViewCustomer", urlPatterns = {"/ViewCustomer"})
public class ViewCustomer extends HttpServlet {

    @EJB
    private CustomerOrderFacade customerOrderFacade;

    @EJB
    private CustomerFacade customerFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession(true);
        PrintWriter out = response.getWriter();
        String userID = request.getParameter("id");
        int id = Integer.parseInt(userID);
        Customer customer = customerFacade.find(id);

        if (customer != null && customer.validCustomer()) {
            htmlHeaderSection(out);
            displayAlert(out, session);
            printDataTable(out, customer, id);
            htmlFooterSection(out);
        } else {
            updateAlert(session, "<Strong>Invalid Customer! </Strong>Customer doesn`t exist.", "warning", "AllCustomers?parent=-1", response);
        }
    }

    /**
     * HTML Content To Display
     */
    private void printDataTable(PrintWriter out, Customer customer, int id) {
        out.println("</form>");
        out.println("<fieldset disabled>");
        out.println("<div class=\"well well-lg\"><h4 class=\"card-title\">ID : " + customer.getId().toString() + "</h4></div>");
        out.println("<div class='form-group row'>");
        out.println("<label for='customerID' class='col-xs-2 col-form-label'>Customer ID</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class='form-control' type='text' value='" + customer.getCustomerId() + "' placeholder='Customer ID' id='customerID' readonly>");
        out.println("</div>");
        out.println("</div>");

        out.println("<div class='form-group row'>");
        out.println("<label for='customerName' class='col-xs-2 col-form-label'>Name</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class='form-control' type='text' value='" + customer.getName() + "'  placeholder='Customer Name' id='customerName'>");
        out.println("</div>");
        out.println("</div>");

        out.println("<div class='form-group row'>");
        out.println("<label for='customerAddress' class='col-xs-2 col-form-label'>Address</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<textarea class='form-control' id='customerAddress' placeholder='Customer Address' rows='5'>" + customer.getAddress() + "</textarea>");
        out.println("</div>");
        out.println("</div>");

        out.println("<div class='form-group row'>");
        out.println("<label for='customerPhone' class='col-xs-2 col-form-label'>Customer Phone</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class='form-control' type='tel' value='" + customer.getPhone() + "' placeholder='Phone' id='customerPhone'>");
        out.println("</div>");
        out.println("</div>");

        out.println("<div class='form-group row'>");
        out.println("<label for='customerStatus' class='col-xs-2 col-form-label'>Customer Status</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class='form-control' type='text' value='" + customer.getStatus() + "'  placeholder='Status' id='customerStatus' readonly>");
        out.println("</div>");
        out.println("</div>");
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        Date date = new Date();
        Date lastDate = customer.getLastUpdate();
        String lastUpdateDate;
        try {
            lastUpdateDate = dateFormat.format(lastDate);
        } catch (Exception e) {
            lastUpdateDate = dateFormat.format(date);
        }
        out.println("<div class='form-group row'>");
        out.println("<label for='customerLastUpdate' class='col-xs-2 col-form-label'>Last Update</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class='form-control' type='text' value='" + lastUpdateDate + "'  placeholder='Customer Last Update' id='customerLastUpdate' readonly>");
        out.println("</div>");
        out.println("</div>");
        out.println("<br/><br/>");

        List orders = customerOrderFacade.findAll();
        List<CustomerOrder> customerOrders = new ArrayList<>();
        for (Iterator iterator = orders.iterator(); iterator.hasNext();) {
            CustomerOrder order = (CustomerOrder) iterator.next();
            if (order.validCustomerOrder() && order.getCustomerId().getId() == id) {
                customerOrders.add(order);
            }
        }
        out.println("<div class=\"well well-lg\"><h4 class=\"card-title\">Pending Orders</h4></div>");

        out.println("<div id='example_wrapper' align='center'>");
        out.println("<table id=\"example\" class=\"table table-striped table-bordered\" cellspacing=\"0\" width=\"100%\">");
        out.println("<thead>");
        out.println("<tr>");
        out.println("<th><Strong>Order ID</Strong></th>");
        out.println("<th><Strong>Amount</Strong></th>");
        out.println("<th><Strong>Due Date</Strong></th>");
        out.println("<th><Strong>Comment</Strong></th>");
        out.println("</tr>");
        out.println("</thead>");
        out.println("<tfoot>");
        out.println("<tr>");
        out.println("<th><Strong>Order ID</Strong></th>");
        out.println("<th><Strong>Amount</Strong></th>");
        out.println("<th><Strong>Due Date</Strong></th>");
        out.println("<th><Strong>Comment</Strong></th>");
        out.println("</tr>");
        out.println("</tfoot>");
        out.println("<tbody>");

        for (CustomerOrder displayOrder : customerOrders) {
            out.println("<tr id = '" + displayOrder.getId().toString() + "'>");
            out.println("<td>" + displayOrder.getOrderId() + "</td>");
            out.println("<td>" + displayOrder.getAmount().toString() + "</td>");
            out.println("<td>" + displayOrder.getDueDate().toString() + "</td>");
            out.println("<td>" + displayOrder.getComment() + "</td>");
            out.println("</tr>");
        }
        out.println("</tbody>");
        out.println("</table>");
        out.println("<Script>");
        out.println("var displayOrderID = -1;");
        out.println("function isNumeric(n) {");
        out.println("return !isNaN(parseFloat(n)) && isFinite(n);");
        out.println("}");
        out.println("$(document).ready(function() {");
        out.println("var table = $('#example').DataTable( {");
        out.println("lengthChange: false,");
        out.println("} );");
        out.println("$('#example tbody').on( 'click', 'tr', function () {");
        out.println("if ( $(this).hasClass('selected') ) {");
        out.println("$(this).removeClass('selected');");
        out.println("displayOrderID = table.$('tr.selected').attr('id',-1);");
        out.println("$('#viewOrderButton').attr('href', 'ViewCustomer');");
        out.println("$(\"#viewOrderButton\").addClass(\"disabled\");");
        out.println("}");
        out.println("else {");
        out.println("table.$('tr.selected').removeClass('selected');");
        out.println("$(this).addClass('selected');");
        out.println("displayOrderID = table.$('tr.selected').attr('id');");
        out.println("$(\"#viewOrderButton\").removeClass(\"disabled\");");
        out.println("$('#viewOrderButton').attr('href', 'ViewOrder?id='+displayOrderID);");
        out.println("}");
        out.println("} );");

        out.println("table.buttons().container()");
        out.println(".appendTo( '#example_wrapper .col-sm-6:eq(0)' );");
        out.println("} );");
        out.println("</Script>");
        out.println("<br/><br/>");

        out.println("</fieldset>");
        out.println("</form>");

        out.println("<div style='display: table;' class=\"container\">");
        out.println("<div style='vertical-align: middle;display: table-cell;' class=\"row\">");
        out.println("<div class=\"btn-toolbar\" role=\"toolbar\" aria-label=\"Operations\">");

        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"Manage Customer\">");
        out.println("<a class='btn btn-primary' href='CreateCustomer'>Create Customer</a>");
        out.println("<a class='btn btn-primary' href='ManageCustomer?id=" + customer.getId() + "'>Update Customer</a>");

        out.println("<button id='deleteModelPopup' type=\"button\" class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#deleteModal\">Delete Customer</button>");
        out.println("</div>");

        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"View Customer\">");
        out.println("<a class='btn btn-primary' href='AllCustomers?parent=-1'>All Customers</a>");
        out.println("<a class='btn btn-primary' href='AllOrders?parent=-1'>All Orders</a>");
        out.println("</div>");

        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"Return to Home\">");
        out.println("<a class='btn btn-primary' href='HomePage'>Home</a>");
        out.println("</div>");

        out.println("</div>");
        out.println("</div>");
        out.println("</div>");

        out.println("<!-- Delete Modal -->");
        out.println("<div id=\"deleteModal\" class=\"modal fade\" role=\"dialog\">");
        out.println("<div class=\"modal-dialog\">");
        out.println("<!-- Modal content-->");
        out.println("<div class=\"modal-content\">");
        out.println("<div class=\"modal-header\">");
        out.println("<button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>");
        out.println("<h4 class=\"modal-title\">Delete Notice</h4>");
        out.println("</div>");
        out.println("<div class=\"modal-body\">");
        out.println("<p id='deleteModelText'>You cannot undo the changes, are you sure?</p>");
        out.println("</div>");
        out.println("<div class=\"modal-footer\">");

        out.println("<a class='btn btn-primary' href='DeleteCustomer?id=" + customer.getId() + "&parent=0'>Delete Customer</a>");

        out.println("<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Cancel</button>");
        out.println("</div>");
        out.println("</div>");
        out.println("</div>");
        out.println("</div>");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "View Customer Servlet";
    }// </editor-fold>

}
