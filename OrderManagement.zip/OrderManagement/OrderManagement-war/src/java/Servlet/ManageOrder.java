/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import CustomerManagementEntity.Customer;
import HTMLCreation.CheckAndValidate;
import HTMLCreation.HTML;
import HTMLCreation.PopUp;
import OrderManagementEntity.CustomerOrder;
import SessionFacadeDAO.CustomerFacade;
import SessionFacadeDAO.CustomerOrderFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Research
 */
@WebServlet(name = "ManageOrder", urlPatterns = {"/ManageOrder"})
public class ManageOrder extends HttpServlet {

    @EJB
    private CustomerOrderFacade customerOrderFacade;
    @EJB
    private CustomerFacade customerFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession(true);
        PrintWriter out = response.getWriter();
        String orderID = request.getParameter("id");
        int customerOrderID = Integer.parseInt(orderID);
        CustomerOrder order = customerOrderFacade.find(customerOrderID);

        if (order != null && order.validCustomerOrder()) {
            HTML.htmlHeaderSection(out);
            PopUp.displayAlert(out, session);
            printDataTable(out, order);
            HTML.htmlFooterSection(out);
        } else {
            PopUp.updateAlert(session, "<Strong>Invalid Order! </Strong>Order doesn`t Exists", "danger", "AllOrders?parent=-1", response);
        }
    }

    /**
     * HTML Content To Display
     */
    private void printDataTable(PrintWriter out, CustomerOrder order) {
        out.println("<form method='POST' data-toggle=\"validator\">");
        out.println("<fieldset disabled>");
        out.println("<div class=\"well well-lg\"><h4 class=\"card-title\">ID : " + order.getId().toString() + "</h4></div>");
        out.println("<div class='form-group row'>");
        out.println("<label for='orderID' class='col-xs-2 col-form-label'>Order ID</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class='form-control' type='text' value='" + order.getOrderId() + "' placeholder='Order ID' id='orderID' readonly>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");

        List<Customer> customerList = customerFacade.findAll();
        out.println("<fieldset>");
        out.println("<div class='form-group row'>");
        out.println("<label for='customerName' class='col-xs-2 col-form-label'>Customer</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<div class=\"well carousel-search hidden-phone\">");
        out.println("<div class=\"btn-group\">");
        out.println("<a id='customerName' class=\"btn dropdown-toggle btn-select\" data-toggle=\"dropdown\" href=\"#\">" + order.getCustomerId().getName() + "<span class=\"caret\"></span></a>");
        out.println("<ul class=\"dropdown-menu\">");
        Customer customer;
        for (Iterator it = customerList.iterator(); it.hasNext();) {
            customer = (Customer) it.next();
            out.println("<li><a id='" + customer.getId().toString() + "' name='" + customer.getName() + "' href=\"#\">" + customer.getName() + "</a></li>");
        }
        out.println("</ul>");
        out.println("</div>");
        out.println("<Script>");
        out.println("$(\".dropdown-menu li a\").click(function(){");
        out.println("var selText = $(this).text();");
        out.println("$(this).parents('.btn-group').find('.dropdown-toggle').html(selText+' <span class=\"caret\"></span>');");
        out.println("$('#nameHidden').attr('value',$(this).attr('id'));");
        out.println("});");
        out.println("</Script>");
        out.println("</div>");
        out.println("</div>");
        out.println("<input type='hidden' name='customerId' value='" + order.getCustomerId().getId() + "' id='nameHidden'/>");
        out.println("</div>");
        out.println("</fieldset>");

        out.println("<fieldset>");
        out.println("<div class='form-group row'>");
        out.println("<label for='customerAmount' class='col-xs-2 col-form-label'>Amount</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class='form-control' pattern='^\\d+(\\.|\\,)\\d{2}$' type='text' name='amount' value='" + new DecimalFormat("#.00").format(order.getAmount().doubleValue()) + "'  placeholder='Amount' id='customerAmount' required>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");

        out.println("<fieldset>");
        out.println("<div class='form-group row'>");
        out.println("<label for='customerDueDate' class='col-xs-2 col-form-label'>Due Date</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class=\"pull-right\" type=\"text\" name=\"birthdate\" value=\"" + new SimpleDateFormat("MM/dd/yyyy").format(new Date()) + "\">");
        out.println("</div>");
        out.println("</div>");
        out.println("<script type=\"text/javascript\">");
        out.println("var today = new Date();var dd = today.getDate();var mm = today.getMonth()+1; var yyyy = today.getFullYear();");
        out.println("if(dd<10) {    dd='0'+dd} if(mm<10) {    mm='0'+mm} ");
        out.println("today = mm+'/'+dd+'/'+yyyy;");
        out.println("$(function() {");
        out.println("$('#dueDateHidden').attr('value',today);");
        out.println("$('input[name=\"birthdate\"]').daterangepicker({");
        out.println("singleDatePicker: true,minDate :today,startDate:" + new SimpleDateFormat("MM/dd/yyyy").format(order.getDueDate()) + ",");
        out.println("showDropdowns: true");
        out.println("},");
        out.println("function(start, end, label) {");
        out.println("var years = moment().diff(start, 'years');");
        out.println("var ende=new Date(end);var dde = ende.getDate();var mme = ende.getMonth()+1; var yyyye = ende.getFullYear();");
        out.println("if(dde<10) {    dde='0'+dde} if(mme<10) {    mme='0'+mme} ");
        out.println("$('#dueDateHidden').attr('value',mme+'/'+dde+'/'+yyyye);");
        out.println("});");
        out.println("});");
        out.println("</script>");
        out.println("<input type='hidden' name='dueDate' value='" + new SimpleDateFormat("MM/dd/yyyy").format(new Date()) + "' id='dueDateHidden'/>");
        out.println("</fieldset>");

        out.println("<fieldset>");
        out.println("<div class='form-group row'>");
        out.println("<label for='customerComment' class='col-xs-2 col-form-label'>Comment</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<textarea name='comment' value='' class='form-control' data-minlength='10' id='customerComment' placeholder='Comments' rows='5' required>" + order.getComment() + "</textarea>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");

        out.println("<fieldset disabled>");
        out.println("<div class='form-group row'>");
        out.println("<label for='orderStatus' class='col-xs-2 col-form-label'>Order Status</label>");
        out.println("<div class='col-xs-10'>");
        String orderStatus = (order.getStatus() != null) ? order.getStatus() : "";
        out.println("<input class='form-control' type='text' value='" + orderStatus + "'  placeholder='Status' id='orderStatus' readonly>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");
        out.println("<fieldset disabled>");
        out.println("<div class='form-group row'>");
        out.println("<label for='orderLastUpdate' class='col-xs-2 col-form-label'>Last Update</label>");
        out.println("<div class='col-xs-10'>");
        String orderLastUpdate = (order.getLastUpdate() != null) ? new SimpleDateFormat("MM/dd/yyyy").format(order.getLastUpdate()) : new SimpleDateFormat("MM/dd/yyyy").format(new Date());
        out.println("<input class='form-control' type='text' value='" + orderLastUpdate + "'  placeholder='Order Last Update' id='orderLastUpdate' readonly>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");

        out.println("<div style='display: table;' class=\"container\">");
        out.println("<div style='vertical-align: middle;display: table-cell;' class=\"row\">");
        out.println("<div class=\"btn-toolbar\" role=\"toolbar\" aria-label=\"Operations\">");

        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"Manage Order\">");
        out.println("<input class='btn btn-primary' type='submit' value=\"Manage Order\"/>");
        out.println("<input class='btn btn-primary' type=\"reset\" value=\"Clear\">");
        out.println("</div>");

        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"View Customer\">");
        out.println("<a class='btn btn-primary' href='AllCustomers?parent=-1'>All Customers</a>");
        out.println("<a class='btn btn-primary' href='AllOrders?parent=-1'>All Orders</a>");
        out.println("</div>");

        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"Return to Home\">");
        out.println("<a class='btn btn-primary' href='ViewOrder?id=" + order.getId().toString() + "'>View Order</a>");
        out.println("<a class='btn btn-primary' href='HomePage'>Home</a>");
        out.println("</div>");

        out.println("</div>");
        out.println("</div>");
        out.println("</div>");

        out.println("</form>");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        int id = Integer.parseInt(request.getParameter("id"));
        int customerId = Integer.parseInt(request.getParameter("customerId"));
        String amount = request.getParameter("amount");
        String comment = request.getParameter("comment");
        String dueDate = request.getParameter("dueDate");

        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        Date dueDateValue = new Date();
        try {
            dueDateValue = dateFormat.parse(dueDate);
        } catch (ParseException e) {
        }
        double amountDouble = CheckAndValidate.round(Double.parseDouble(amount), 2);
        BigDecimal amountValue = BigDecimal.valueOf(amountDouble);
        try {
            if (CheckAndValidate.validateOrderRequestParameters(amount, comment, dueDate, customerId)) {
                CustomerOrder order = (CustomerOrder) customerOrderFacade.find(id);

                if (new DecimalFormat("#.00").format(order.getAmount().doubleValue()).compareTo(amount) == 0 && comment.compareToIgnoreCase(order.getComment()) == 0 && dueDateValue.compareTo(order.getDueDate()) == 0) {
                    PopUp.updateAlert(session, "<Strong>Information Upto Date! </Strong>No changes have been made", "info", "ManageOrder?id=" + id, response);
                } else {
                    order.setAmount(amountValue);
                    order.setComment(comment);
                    order.setDueDate(dueDateValue);
                    order.setCustomerId(customerFacade.find(customerId));
                    order.setStatus("VALID");
                    customerOrderFacade.edit(order);
                    PopUp.updateAlert(session, "<Strong>Update Success! </Strong>Order information updated", "success", "ManageOrder?id=" + id, response);
                }
            } else {
                PopUp.updateAlert(session, "<Strong>Invalid Information! </Strong>Please try again shortly", "danger", "AllOrders?parent=-1", response);
            }
        } catch (NullPointerException ex) {
            PopUp.updateAlert(session, "<Strong>Invalid Order! </Strong>Order doesn`t Exists", "danger", "AllOrders?parent=-1", response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
