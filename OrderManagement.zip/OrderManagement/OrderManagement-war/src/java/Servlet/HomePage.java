/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import HTMLCreation.HTML;
import HTMLCreation.PopUp;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Research
 */
@WebServlet(name = "HomePage", urlPatterns = {"/HomePage"})
public class HomePage extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession(true);
        try (PrintWriter out = response.getWriter()) {

            HTML.htmlHeaderSection(out);
            PopUp.displayAlert(out, session);

            printDataTable(out);

            HTML.htmlFooterSection(out);
        }
    }

    /**
     * HTML Content To Display
     */
    private void printDataTable(final PrintWriter out) {
        out.println("<div class=\"well well-lg\"><h4 class=\"card-title\">All things Customers</h4></div>");
        out.println("<div class=\"card-group\">");
        out.println("<div class=\"card text-xs-center\">");
        out.println("<div class=\"card-block\">");
        out.println("<h4 class=\"card-title\">Create Customer</h4>");
        out.println("<p class=\"card-text\">Add a new user to the Order Management</p>");
        out.println("<a href=\"CreateCustomer\" class=\"btn btn-primary\">Create</a>");
        out.println("</div>");
        out.println("</div>");
        out.println("<div class=\"card text-xs-center\">");
        out.println("<div class=\"card-block\">");
        out.println("<h4 class=\"card-title\">Manage Customer</h4>");
        out.println("<p class=\"card-text\">Edit user information in the Order Management</p>");
        out.println("<a href=\"AllCustomers?parent=1\" class=\"btn btn-primary\">Manage</a>");
        out.println("</div>");
        out.println("</div>");
        out.println("<div class=\"card text-xs-center\">");
        out.println("<div class=\"card-block\">");
        out.println("<h4 class=\"card-title\">Delete Customer</h4>");
        out.println("<p class=\"card-text\">Delete user Information from the Order Management</p>");
        out.println("<a href=\"AllCustomers?parent=2\" class=\"btn btn-primary\">Delete</a>");
        out.println("</div>");
        out.println("</div>");
        out.println("<div class=\"card text-xs-center\">");
        out.println("<div class=\"card-block\">");
        out.println("<h4 class=\"card-title\">All Customers</h4>");
        out.println("<p class=\"card-text\">Display All Available users in the Order Management</p>");
        out.println("<a href=\"AllCustomers?parent=-1\" class=\"btn btn-primary\">View</a>");
        out.println("</div>");
        out.println("</div>");
        out.println("<div class=\"card text-xs-center\">");
        out.println("<div class=\"card-block\">");
        out.println("<h4 class=\"card-title\">View Customer</h4>");
        out.println("<p class=\"card-text\">Display user information</p>");
        out.println("<a href=\"AllCustomers?parent=3\" class=\"btn btn-primary\">View</a>");
        out.println("</div>");
        out.println("</div>");
        out.println("</div>");
        out.println("<br/>");
        out.println("<div class=\"well well-lg\"><h4 class=\"card-title\">All things Customer Orders</h4></div>");
        out.println("<div class=\"card-group\">");
        out.println("<div class=\"card text-xs-center\">");
        out.println("<div class=\"card-block\">");
        out.println("<h4 class=\"card-title\">Create Order</h4>");
        out.println("<p class=\"card-text\">Add a new Order to the Order Management</p>");
        out.println("<a href=\"CreateOrder\" class=\"btn btn-primary\">Create</a>");
        out.println("</div>");
        out.println("</div>");
        out.println("<div class=\"card text-xs-center\">");
        out.println("<div class=\"card-block\">");
        out.println("<h4 class=\"card-title\">Manage Order</h4>");
        out.println("<p class=\"card-text\">Edit order information in the Order Management</p>");
        out.println("<a href=\"AllOrders?parent=1\" class=\"btn btn-primary\">Manage</a>");
        out.println("</div>");
        out.println("</div>");
        out.println("<div class=\"card text-xs-center\">");
        out.println("<div class=\"card-block\">");
        out.println("<h4 class=\"card-title\">Delete Order</h4>");
        out.println("<p class=\"card-text\">You are not allowed to delete Information from the Order Management</p>");
        out.println("<a href=\"#\" class=\"btn btn-primary disabled\">Delete</a>");
        out.println("</div>");
        out.println("</div>");
        out.println("<div class=\"card text-xs-center\">");
        out.println("<div class=\"card-block\">");
        out.println("<h4 class=\"card-title\">All Orders</h4>");
        out.println("<p class=\"card-text\">Display All Available orders in the Order Management</p>");
        out.println("<a href=\"AllOrders?parent=-1\" class=\"btn btn-primary\">View</a>");
        out.println("</div>");
        out.println("</div>");
        out.println("<div class=\"card text-xs-center\">");
        out.println("<div class=\"card-block\">");
        out.println("<h4 class=\"card-title\">View Order</h4>");
        out.println("<p class=\"card-text\">Display order information</p>");
        out.println("<a href=\"AllOrders?parent=2\" class=\"btn btn-primary\">View</a>");
        out.println("</div>");
        out.println("</div>");
        out.println("</div>");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Home Page Servlet";
    }// </editor-fold>
}
