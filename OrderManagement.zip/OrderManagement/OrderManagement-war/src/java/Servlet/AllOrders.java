/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import HTMLCreation.HTML;
import HTMLCreation.PopUp;
import OrderManagementEntity.CustomerOrder;
import SessionFacadeDAO.CustomerOrderFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Research
 */
@WebServlet(name = "AllOrders", urlPatterns = {"/AllOrders"})
public class AllOrders extends HttpServlet {

    @EJB
    private CustomerOrderFacade customerOrderFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        response.setContentType("text/html;charset=UTF-8");
        String customerParent = request.getParameter("parent");
        int parentID = Integer.parseInt(customerParent);
        switch (parentID) {
            case 1:
                PopUp.updateMessage(session, "<Strong>You are One Step away to Manage an Order! </Strong> Select an Order first, then Click Manage Order", "info", response);
                break;
            case 2:
                PopUp.updateMessage(session, "<Strong>You are One Step away to View an Order! </Strong> Select an Order first, then Click View Order", "info", response);
                break;
            default:
                break;
        }
        try (PrintWriter out = response.getWriter()) {
            List<CustomerOrder> orders = customerOrderFacade.findAll();
            if (orders != null && !orders.isEmpty()) {
                printDataTable(orders, out, session);
            } else {
                PopUp.updateAlert(session, "<Strong>We don`t have any Orders.</Strong> Please add new Orders.", "info", "HomePage", response);
            }
        } catch (Exception e) {
            PopUp.updateAlert(session, "<Strong>We are experiencing some trouble.</Strong> Please try again in a few moment.", "warning", "HomePage", response);
        }
    }

    /**
     * HTML Content To Display
     */
    private void printDataTable(List<CustomerOrder> orders, PrintWriter out, HttpSession session) {
        HTML.htmlHeaderSection(out);
        PopUp.displayAlert(out, session);
        out.println("<h2>All Orders</h2>");

        out.println("<div id='example_wrapper' align='center'>");
        out.println("<table id=\"example\" class=\"table table-striped table-bordered\" cellspacing=\"0\" width=\"100%\">");
        out.println("<thead>");
        out.println("<tr>");
        out.println("<th><Strong>Order ID</Strong></th>");
        out.println("<th><Strong>Customer</Strong></th>");
        out.println("<th><Strong>Amount</Strong></th>");
        out.println("<th><Strong>Due Date</Strong></th>");
        out.println("<th><Strong>Comment</Strong></th>");
        out.println("</tr>");
        out.println("</thead>");
        out.println("<tfoot>");
        out.println("<tr>");
        out.println("<th><Strong>Order ID</Strong></th>");
        out.println("<th><Strong>Customer</Strong></th>");
        out.println("<th><Strong>Amount</Strong></th>");
        out.println("<th><Strong>Due Date</Strong></th>");
        out.println("<th><Strong>Comment</Strong></th>");
        out.println("</tr>");
        out.println("</tfoot>");
        out.println("<tbody>");

        for (CustomerOrder displayOrder : orders) {
            out.println("<tr id = '" + displayOrder.getId().toString() + "'>");
            out.println("<td>" + displayOrder.getOrderId() + "</td>");
            out.println("<td>" + displayOrder.getCustomerId().getName() + "</td>");
            out.println("<td>" + displayOrder.getAmount().toString() + "</td>");
            out.println("<td>" + displayOrder.getDueDate().toString() + "</td>");
            out.println("<td>" + displayOrder.getComment() + "</td>");
            out.println("</tr>");
        }
        out.println("</tbody>");
        out.println("</table>");

        out.println("<Script>");
        out.println("var displayOrderID = -1;");
        out.println("function isNumeric(n) {");
        out.println("return !isNaN(parseFloat(n)) && isFinite(n);");
        out.println("}");
        out.println("$(document).ready(function() {");
        out.println("var table = $('#example').DataTable( {");
        out.println("lengthChange: false,");
        out.println("} );");
        out.println("$('#example tbody').on( 'click', 'tr', function () {");
        out.println("if ( $(this).hasClass('selected') ) {");
        out.println("$(this).removeClass('selected');");
        out.println("displayOrderID = table.$('tr.selected').attr('id',-1);");
        out.println("$('#viewOrderButton').attr('href', 'AllOrders?parent=-1');");
        out.println("$(\"#viewOrderButton\").addClass(\"disabled\");");
        out.println("$('#manageOrderButton').attr('href', 'AllOrders?parent=-1');");
        out.println("$(\"#manageOrderButton\").addClass(\"disabled\");");
        out.println("}");
        out.println("else {");
        out.println("table.$('tr.selected').removeClass('selected');");
        out.println("$(this).addClass('selected');");
        out.println("displayOrderID = table.$('tr.selected').attr('id');");
        out.println("$(\"#viewOrderButton\").removeClass(\"disabled\");");
        out.println("$('#viewOrderButton').attr('href', 'ViewOrder?id='+displayOrderID);");
        out.println("$(\"#manageOrderButton\").removeClass(\"disabled\");");
        out.println("$('#manageOrderButton').attr('href', 'ManageOrder?id='+displayOrderID);");
        out.println("}");
        out.println("} );");

        out.println("table.buttons().container()");
        out.println(".appendTo( '#example_wrapper .col-sm-6:eq(0)' );");
        out.println("} );");
        out.println("</Script>");
        out.println("<br/><br/>");

        out.println("<div style='display: table;' class=\"container\">");
        out.println("<div style='vertical-align: middle;display: table-cell;' class=\"row\">");
        out.println("<div class=\"btn-toolbar\" role=\"toolbar\" aria-label=\"Operations\">");

        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"Manage Order\">");
        out.println("<a id='viewOrderButton' class='btn btn-primary disabled' href='AllOrders?parent=-1'>View Order</a>");
        out.println("<a id='manageOrderButton' class='btn btn-primary disabled' href='AllOrders?parent=-1'>Manage Order</a>");
        out.println("</div>");

        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"New Order\">");
        out.println("<a class='btn btn-primary' href='CreateCustomer'>Create Customer</a>");
        out.println("<a class='btn btn-primary' href='CreateOrder'>Create Order</a>");
        out.println("</div>");

        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"View Customer\">");
        out.println("<a class='btn btn-primary' href='AllCustomers?parent=-1'>All Customers</a>");
        out.println("<a class='btn btn-primary' href='AllOrders?parent=-1'>All Orders</a>");
        out.println("</div>");

        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"Return to Home\">");
        out.println("<a class='btn btn-primary' href='HomePage'>Home</a>");
        out.println("</div>");

        out.println("</div>");
        out.println("</div>");
        out.println("</div>");

        out.println("</div>");
        HTML.htmlFooterSection(out);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
