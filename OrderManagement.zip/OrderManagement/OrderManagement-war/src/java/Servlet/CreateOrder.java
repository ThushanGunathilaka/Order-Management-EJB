/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import CustomerManagementEntity.Customer;
import HTMLCreation.CheckAndValidate;
import HTMLCreation.HTML;
import HTMLCreation.PopUp;
import OrderManagementEntity.CustomerOrder;
import SessionFacadeDAO.CustomerFacade;
import SessionFacadeDAO.CustomerOrderFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.enterprise.inject.InjectionException;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Research
 */
@WebServlet(name = "CreateOrder", urlPatterns = {"/CreateOrder"})
public class CreateOrder extends HttpServlet {

    @EJB
    private CustomerOrderFacade customerOrderFacade;

    @Resource(mappedName = "jms/CreateOrderMDB")
    private Queue queue;

    @Resource(mappedName = "jms/CreateOrderMDBFactory")
    private ConnectionFactory connectionFactory;

    @EJB
    private CustomerFacade customerFacade;

    private static Customer customer;
    private static CustomerOrder order;
    private static List<Customer> customers;
    private static List<CustomerOrder> orders;

    public CreateOrder() {
        customer = new Customer();
        order = new CustomerOrder();
        customers = new ArrayList<>();
        orders = new ArrayList<>();
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession(true);
        customers = customerFacade.findAll();
        try (PrintWriter out = response.getWriter()) {
            if (customers != null && !customers.isEmpty()) {
                HTML.htmlHeaderSection(out);
                PopUp.displayAlert(out, session);
                printDataTable(out, customers);
                HTML.htmlFooterSection(out);
            } else {
                PopUp.updateAlert(session, "<Strong>We don`t have any customers.</Strong> Please add new customers.", "info", "HomePage", response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        PrintWriter out = response.getWriter();
        HttpSession httpSession = request.getSession(false);
        try {
            //Query Strings  
            String comment = request.getParameter("comment");
            String amount = request.getParameter("amount");
            String dueDateString = request.getParameter("dueDate");
            int customerId = Integer.parseInt(request.getParameter("customerId"));
            customer = customerFacade.find(customerId);
            DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
            Date dueDate = new Date();
            try {
                dueDate = dateFormat.parse(dueDateString);
            } catch (ParseException e) {
            }
            orders = customerOrderFacade.findAll();
            int maxOrderID = 0;
            for (CustomerOrder element : orders) {
                if (maxOrderID < element.getId()) {
                    maxOrderID = element.getId();
                }
            }
            maxOrderID++;
            int newOrderID = maxOrderID + 1000;
            String orderId = CheckAndValidate.genString('A', 2) + String.valueOf(newOrderID);
            if (validateCustomerOrderData(comment, amount, dueDateString)) {
                Connection connection = connectionFactory.createConnection();
                Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
                MessageProducer messageProducer = session.createProducer(queue);
                ObjectMessage message = session.createObjectMessage();
                order.setAmount(BigDecimal.valueOf(Double.valueOf(amount)));
                order.setComment(comment);
                order.setDueDate(dueDate);
                order.setOrderId(orderId);
                order.setCustomerId(customer);
                order.setStatus("VALID");
                message.setObject(order);
                messageProducer.send(message);
                messageProducer.close();
                connection.close();
                PopUp.updateAlert(httpSession, "<Strong>Order Created! </Strong> your order has been placed.", "success", "ViewOrder?id=" + String.valueOf(maxOrderID), response);
            }
        } catch (NumberFormatException ex1) {
            PopUp.updateAlert(httpSession, "<Strong>Invalid Order! </Strong>You have some given unusable Information. Please try again", "warning", "AllOrders?parent=-1", response);
        } catch (InjectionException | JMSException ex2) {
            PopUp.updateAlert(httpSession, "<Strong>Error Creating Order! </Strong>We have encountered some issues. Please try again", "warning", "AllOrders?parent=-1", response);
        }
    }

    /**
     * Method parameter extraction
     */
    private static boolean validateCustomerOrderData(String comment, String amount, String dueDateString) {
        return customer != null && order != null
                && CheckAndValidate.validateRequestParameters(comment, amount, dueDateString);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Create Order Servlet";
    }// </editor-fold>

    /**
     * HTML Content To Display
     */
    private void printDataTable(PrintWriter out, List<Customer> customers) {
        out.println("<form method='POST' data-toggle=\"validator\">");
        out.println("<fieldset disabled>");
        out.println("<div class=\"well well-lg\"><h4 class=\"card-title\">ID : New Order ID</h4></div>");
        out.println("<div class='form-group row'>");
        out.println("<label for='orderID' class='col-xs-2 col-form-label'>Order ID</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class='form-control' type='text' value='New Order ID' placeholder='Order ID' id='orderID' readonly>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");

        out.println("<fieldset>");
        out.println("<div class='form-group row'>");
        out.println("<label for='customerName' class='col-xs-2 col-form-label'>Customer</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<div class=\"well carousel-search hidden-phone\">");
        out.println("<div class=\"btn-group\">");
        out.println("<a id='customerName' class=\"btn dropdown-toggle btn-select\" data-toggle=\"dropdown\" href=\"#\">" + customers.get(0).getName() + "<span class=\"caret\"></span></a>");
        out.println("<ul class=\"dropdown-menu\">");
        Customer element;
        for (Iterator it = customers.iterator(); it.hasNext();) {
            element = (Customer) it.next();
            out.println("<li><a id='" + element.getId().toString() + "' name='" + element.getName() + "' href=\"#\">" + element.getName() + "</a></li>");
        }
        out.println("</ul>");
        out.println("</div>");
        out.println("<Script>");
        out.println("$(\".dropdown-menu li a\").click(function(){");
        out.println("var selText = $(this).text();");
        out.println("$(this).parents('.btn-group').find('.dropdown-toggle').html(selText+' <span class=\"caret\"></span>');");
        out.println("$('#nameHidden').attr('value',$(this).attr('id'));");
        out.println("});");
        out.println("</Script>");
        out.println("</div>");
        out.println("</div>");
        out.println("<input type='hidden' name='customerId' value='" + customers.get(0).getId() + "' id='nameHidden'/>");
        out.println("</div>");
        out.println("</fieldset>");

        out.println("<fieldset>");
        out.println("<div class='form-group row'>");
        out.println("<label for='customerAmount' class='col-xs-2 col-form-label'>Amount</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class='form-control' pattern='^\\d+(\\.|\\,)\\d{2}$' type='text' name='amount' value=''  placeholder='Amount' id='customerAmount' required>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");

        out.println("<fieldset>");
        out.println("<div class='form-group row'>");
        out.println("<label for='customerDueDate' class='col-xs-2 col-form-label'>Due Date</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class=\"pull-right\" type=\"text\" name=\"birthdate\" value=\"" + new SimpleDateFormat("MM/dd/yyyy").format(new Date()) + "\">");
        out.println("</div>");
        out.println("</div>");
        out.println("<script type=\"text/javascript\">");
        out.println("var today = new Date();var dd = today.getDate();var mm = today.getMonth()+1; var yyyy = today.getFullYear();");
        out.println("if(dd<10) {    dd='0'+dd} if(mm<10) {    mm='0'+mm} ");
        out.println("today = mm+'/'+dd+'/'+yyyy;");
        out.println("$(function() {");
        out.println("$('#dueDateHidden').attr('value',today);");
        out.println("$('input[name=\"birthdate\"]').daterangepicker({");
        out.println("singleDatePicker: true,minDate :today,startDate:" + new SimpleDateFormat("MM/dd/yyyy").format(new Date()) + ",");
        out.println("showDropdowns: true");
        out.println("},");
        out.println("function(start, end, label) {");
        out.println("var years = moment().diff(start, 'years');");
        out.println("var ende=new Date(end);var dde = ende.getDate();var mme = ende.getMonth()+1; var yyyye = ende.getFullYear();");
        out.println("if(dde<10) {    dde='0'+dde} if(mme<10) {    mme='0'+mme} ");
        out.println("$('#dueDateHidden').attr('value',mme+'/'+dde+'/'+yyyye);");
        out.println("});");
        out.println("});");
        out.println("</script>");
        out.println("<input type='hidden' name='dueDate' value='" + new SimpleDateFormat("MM/dd/yyyy").format(new Date()) + "' id='dueDateHidden'/>");
        out.println("</fieldset>");

        out.println("<fieldset>");
        out.println("<div class='form-group row'>");
        out.println("<label for='customerComment' class='col-xs-2 col-form-label'>Comment</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<textarea name='comment' value='' class='form-control' data-minlength='10' id='customerComment' placeholder='Comments' rows='5' required></textarea>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");

        out.println("<fieldset disabled>");
        out.println("<div class='form-group row'>");
        out.println("<label for='orderStatus' class='col-xs-2 col-form-label'>Order Status</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class='form-control' type='text' value='VALID'  placeholder='Status' id='orderStatus' readonly>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");
        out.println("<fieldset disabled>");
        out.println("<div class='form-group row'>");
        out.println("<label for='orderLastUpdate' class='col-xs-2 col-form-label'>Created On</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class='form-control' type='text' value='" + new SimpleDateFormat("MM/dd/yyyy").format(new Date()) + "'  placeholder='Order Last Update' id='orderLastUpdate' readonly>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");

        out.println("<div style='display: table;' class=\"container\">");
        out.println("<div style='vertical-align: middle;display: table-cell;' class=\"row\">");
        out.println("<div class=\"btn-toolbar\" role=\"toolbar\" aria-label=\"Operations\">");

        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"Manage Order\">");
        out.println("<input class='btn btn-primary' type='submit' value=\"Create Order\"/>");
        out.println("<input class='btn btn-primary' type=\"reset\" value=\"Clear\"/>");
        out.println("</div>");

        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"View Customer\">");
        out.println("<a class='btn btn-primary' href='AllCustomers?parent=-1'>All Customers</a>");
        out.println("<a class='btn btn-primary' href='AllOrders?parent=-1'>All Orders</a>");
        out.println("</div>");

        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"Return to Home\">");
        out.println("<a class='btn btn-primary' href='HomePage'>Home</a>");
        out.println("</div>");

        out.println("</div>");
        out.println("</div>");
        out.println("</div>");

        out.println("</form>");
    }
}
