/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import HTMLCreation.HTML;
import HTMLCreation.PopUp;
import OrderManagementEntity.CustomerOrder;
import SessionFacadeDAO.CustomerFacade;
import SessionFacadeDAO.CustomerOrderFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Research
 */
@WebServlet(name = "ViewOrder", urlPatterns = {"/ViewOrder"})
public class ViewOrder extends HttpServlet {

    @EJB
    private CustomerOrderFacade customerOrderFacade;
    @EJB
    private CustomerFacade customerFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession(true);
        PrintWriter out = response.getWriter();
        String orderID = request.getParameter("id");
        int customerOrderID = Integer.parseInt(orderID);
        CustomerOrder order = customerOrderFacade.find(customerOrderID);
        if (order != null && order.validCustomerOrder()) {
            HTML.htmlHeaderSection(out);
            PopUp.displayAlert(out, session);
            printDataTable(out, order);
            HTML.htmlFooterSection(out);
        } else {
            PopUp.updateAlert(session, "<Strong>Invalid Order! </Strong>Order doesn`t Exists", "danger", "AllOrders?parent=-1", response);
        }
    }

    /**
     * HTML Content To Display
     */
    private void printDataTable(PrintWriter out, CustomerOrder order) {
        out.println("<form method='POST' data-toggle=\"validator\">");
        out.println("<fieldset disabled>");
        out.println("<div class=\"well well-lg\"><h4 class=\"card-title\">ID : " + order.getId().toString() + "</h4></div>");
        out.println("<div class='form-group row'>");
        out.println("<label for='orderID' class='col-xs-2 col-form-label'>Order ID</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class='form-control' type='text' value='" + order.getOrderId() + "' placeholder='Order ID' id='orderID' readonly>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");

        out.println("<fieldset disabled>");
        out.println("<div class='form-group row'>");
        out.println("<label for='customerName' class='col-xs-2 col-form-label'>Customer</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class='form-control' type='text' name='customerName' value='" + order.getCustomerId().getName() + "' placeholder='Customer' id='customerName' required>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");

        out.println("<fieldset disabled>");
        out.println("<div class='form-group row'>");
        out.println("<label for='customerAmount' class='col-xs-2 col-form-label'>Amount</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class='form-control' pattern='^\\d+(\\.|\\,)\\d{2}$' type='text' name='amount' value='" + new DecimalFormat("#.00").format(order.getAmount().doubleValue()) + "'  placeholder='Amount' id='customerAmount' required>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");

        out.println("<fieldset disabled>");
        out.println("<div class='form-group row'>");
        out.println("<label for='customerDueDate' class='col-xs-2 col-form-label'>Due Date</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<input class='form-control' type='text' data-minlength='10' name='comment' value='" + new SimpleDateFormat("MM/dd/yyyy").format(new Date()) + "' placeholder='Due Date' id='customerDueDate' required>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");

        out.println("<fieldset disabled>");
        out.println("<div class='form-group row'>");
        out.println("<label for='customerComment' class='col-xs-2 col-form-label'>Comment</label>");
        out.println("<div class='col-xs-10'>");
        out.println("<textarea name='comment' value='' class='form-control' data-minlength='10' id='customerComment' placeholder='Comments' rows='5' required>" + order.getComment() + "</textarea>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");

        out.println("<fieldset disabled>");
        out.println("<div class='form-group row'>");
        out.println("<label for='orderStatus' class='col-xs-2 col-form-label'>Order Status</label>");
        out.println("<div class='col-xs-10'>");
        String orderStatus = (order.getStatus() != null) ? order.getStatus() : "";
        out.println("<input class='form-control' type='text' value='" + orderStatus + "'  placeholder='Status' id='orderStatus' readonly>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");
        out.println("<fieldset disabled>");
        out.println("<div class='form-group row'>");
        out.println("<label for='orderLastUpdate' class='col-xs-2 col-form-label'>Last Update</label>");
        out.println("<div class='col-xs-10'>");
        String orderLastUpdate = (order.getLastUpdate() != null) ? new SimpleDateFormat("MM/dd/yyyy").format(order.getLastUpdate()) : new SimpleDateFormat("MM/dd/yyyy").format(new Date());
        out.println("<input class='form-control' type='text' value='" + orderLastUpdate + "'  placeholder='Order Last Update' id='orderLastUpdate' readonly>");
        out.println("</div>");
        out.println("</div>");
        out.println("</fieldset>");

        out.println("<div style='display: table;' class=\"container\">");
        out.println("<div style='vertical-align: middle;display: table-cell;' class=\"row\">");
        out.println("<div class=\"btn-toolbar\" role=\"toolbar\" aria-label=\"Operations\">");

        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"View Customer\">");
        out.println("<a class='btn btn-primary' href='AllCustomers?parent=-1'>All Customers</a>");
        out.println("<a class='btn btn-primary' href='AllOrders?parent=-1'>All Orders</a>");
        out.println("</div>");

        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"Return to Home\">");
        out.println("<a class='btn btn-primary' href='ManageOrder?id=" + order.getId().toString() + "'>Manage Order</a>");
        out.println("<a class='btn btn-primary' href='HomePage'>Home</a>");
        out.println("</div>");

        out.println("</div>");
        out.println("</div>");
        out.println("</div>");

        out.println("</form>");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
