/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import CustomerManagementEntity.Customer;
import HTMLCreation.CheckAndValidate;
import HTMLCreation.HTML;
import HTMLCreation.PopUp;
import SessionFacadeDAO.CustomerFacade;
import SessionFacadeDAO.CustomerOrderFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Research
 */
@WebServlet(name = "AllCustomers", urlPatterns = {"/AllCustomers"})
public class AllCustomers extends HttpServlet {

    @EJB
    private CustomerOrderFacade customerOrderFacade;

    @EJB
    private CustomerFacade customerFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        response.setContentType("text/html;charset=UTF-8");
        String customerParent = request.getParameter("parent");
        int parentID = Integer.parseInt(customerParent);
        switch (parentID) {
            case 1:
                PopUp.updateMessage(session, "<Strong>You are One Step away to Manage a Customer! </Strong> Select a customer first, then Click Manage Customer", "info", response);
                break;
            case 2:
                PopUp.updateMessage(session, "<Strong>You are One Step away to Delete a Customer! </Strong> Select a customer first, then Click Delete Customer", "info", response);
                break;
            case 3:
                PopUp.updateMessage(session, "<Strong>You are One Step away to View a Customer! </Strong> Select a customer first, then Click View Customer", "info", response);
                break;
            default:
                break;
        }
        try (PrintWriter out = response.getWriter()) {
            List customers = customerFacade.findAll();
            if (customers != null && !customers.isEmpty()) {
                printDataTable(customers, out, session);
            } else {
                PopUp.updateAlert(session, "<Strong>We don`t have any customers.</Strong> Please add new customers.", "info", "HomePage", response);
            }
        } catch (Exception e) {
            PopUp.updateAlert(session, "<Strong>We are experiencing some trouble.</Strong> Please try again in a few moment.", "warning", "HomePage", response);
        }
    }

    /**
     * HTML Content To Display
     */
    private void printDataTable(List customers, PrintWriter out, HttpSession session) {
        HTML.htmlHeaderSection(out);
        PopUp.displayAlert(out, session);
        out.println("<h2>All Customers</h2>");
        out.println("<div id='example_wrapper' align='center'>");
        out.println("<table id=\"example\" class=\"table table-striped table-bordered\" cellspacing=\"0\" width=\"100%\">");
        out.println("<thead>");
        out.println("<tr>");
        out.println("<th><Strong>Customer ID</Strong></th>");
        out.println("<th><Strong>Name</Strong></th>");
        out.println("<th><Strong>Address</Strong></th>");
        out.println("<th><Strong>Phone</Strong></th>");
        out.println("</tr>");
        out.println("</thead>");
        out.println("<tfoot>");
        out.println("<tr>");
        out.println("<th><Strong>Customer ID</Strong></th>");
        out.println("<th><Strong>Name</Strong></th>");
        out.println("<th><Strong>Address</Strong></th>");
        out.println("<th><Strong>Phone</Strong></th>");
        out.println("</tr>");
        out.println("</tfoot>");
        out.println("<tbody>");

        for (Iterator it = customers.iterator(); it.hasNext();) {
            Customer customer = (Customer) it.next();
            out.println("<tr id = '" + customer.getId().toString() + "' name='" + CheckAndValidate.checkPendingOrdersForCustomer(customer.getId(), customerOrderFacade) + "'>");
            out.println("<td>" + customer.getCustomerId() + "</td>");
            out.println("<td>" + customer.getName() + "</td>");
            out.println("<td>" + customer.getAddress() + "</td>");
            out.println("<td>" + customer.getPhone() + "</td>");
            out.println("</tr>");
        }
        out.println("</tbody>");
        out.println("</table>");
        out.println("<Script>");
        out.println("var selectedItemId = -1;");
        out.println("var deleteEligible = 'false';");
        out.println("function isNumeric(n) {");
        out.println("return !isNaN(parseFloat(n)) && isFinite(n);");
        out.println("}");
        out.println("$(document).ready(function() {");
        out.println("var table = $('#example').DataTable( {");
        out.println("lengthChange: false,");
        out.println("} );");
        out.println("$('#example tbody').on( 'click', 'tr', function () {");
        out.println("if ( $(this).hasClass('selected') ) {");
        out.println("$(this).removeClass('selected');");
        out.println("selectedItemId = table.$('tr.selected').attr('id',-1);");
        out.println("deleteEligible = table.$('tr.selected').attr('name','true');");
        out.println("$('#deleteModelSubmit').attr('href', 'AllCustomers?parent=-1');");
        out.println("$('#viewCustomerButton').attr('href', 'AllCustomers?parent=-1');");
        out.println("$('#manageCustomerButton').attr('href', 'AllCustomers?parent=-1');");
        out.println("$(\"#deleteModelPopup\").addClass(\"disabled\");");
        out.println("$(\"#viewCustomerButton\").addClass(\"disabled\");");
        out.println("$('#manageCustomerButton').addClass(\"disabled\");");
        out.println("}");
        out.println("else {");
        out.println("table.$('tr.selected').removeClass('selected');");
        out.println("$(this).addClass('selected');");
        out.println("selectedItemId = table.$('tr.selected').attr('id');");
        out.println("deleteEligible = table.$('tr.selected').attr('name');");
        out.println("$(\"#deleteModelPopup\").removeClass(\"disabled\");");
        out.println("$(\"#viewCustomerButton\").removeClass(\"disabled\");");
        out.println("$('#manageCustomerButton').removeClass(\"disabled\");");
        out.println("$('#deleteModelSubmit').attr('href', 'DeleteCustomer?id='+selectedItemId+'&parent=-1');");
        out.println("$('#viewCustomerButton').attr('href', 'ViewCustomer?id='+selectedItemId);");
        out.println("$('#manageCustomerButton').attr('href', 'ManageCustomer?id='+selectedItemId);");
        out.println("}");
        out.println("} );");

        out.println("$('#deleteModelPopup').click( function () {");
        out.println("if(isNumeric(selectedItemId) && selectedItemId > -1) {");
        out.println("if(deleteEligible == 'true'){");
        out.println("document.getElementById('deleteModelText').innerHTML = 'This user have pending orders.Try again when orders are complete';");
        out.println("$(\"#deleteModelSubmit\").addClass(\"disabled\");");
        out.println("}else{");
        out.println("document.getElementById('deleteModelText').innerHTML = 'You cannot undo the changes, are you sure?';");
        out.println("$(\"#deleteModelSubmit\").removeClass(\"disabled\");");
        out.println("}");
        out.println("} else {");
        out.println("document.getElementById('deleteModelText').innerHTML = 'Select a Customer from the table';");
        out.println("$(\"#deleteModelSubmit\").addClass(\"disabled\");");
        out.println("}");
        out.println("} );");

        out.println("table.buttons().container()");
        out.println(".appendTo( '#example_wrapper .col-sm-6:eq(0)' );");
        out.println("} );");
        out.println("</Script>");
        out.println("<br/><br/>");
        out.println("<div style='display: table;' class=\"container\">");
        out.println("<div style='vertical-align: middle;display: table-cell;' class=\"row\">");
        out.println("<div class=\"btn-toolbar\" role=\"toolbar\" aria-label=\"Operations\">");
        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"Manage Customer\">");
        out.println("<a class='btn btn-primary' href='CreateCustomer'>Create Customer</a>");
        out.println("<a id='manageCustomerButton' class='btn btn-primary disabled' href='AllCustomers?parent=-1'>Manage Customer</a>");
        out.println("<button id='deleteModelPopup' type=\"button\" class=\"btn btn-primary disabled\" data-toggle=\"modal\" data-target=\"#deleteModal\">Delete Customer</button>");
        out.println("</div>");
        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"View Customer\">");
        out.println("<a id='viewCustomerButton' class='btn btn-primary disabled' href='AllCustomers?parent=-1'>View Customer</a>");
        out.println("</div>");
        out.println("<div class=\"btn-group\" role=\"group\" aria-label=\"Return to Home\">");
        out.println("<a class='btn btn-primary' href='AllOrders?parent=-1'>All Orders</a>");
        out.println("<a class='btn btn-primary' href='HomePage'>Home</a>");
        out.println("</div>");
        out.println("</div>");
        out.println("</div>");
        out.println("</div>");

        out.println("<!-- Delete Modal -->");
        out.println("<div id=\"deleteModal\" class=\"modal fade\" role=\"dialog\">");
        out.println("<div class=\"modal-dialog\">");
        out.println("<!-- Modal content-->");
        out.println("<div class=\"modal-content\">");
        out.println("<div class=\"modal-header\">");
        out.println("<button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>");
        out.println("<h4 class=\"modal-title\">Delete Notice</h4>");
        out.println("</div>");
        out.println("<div class=\"modal-body\">");
        out.println("<p id='deleteModelText'>Close the popupbox and try again</p>");
        out.println("</div>");
        out.println("<div class=\"modal-footer\">");

        out.println("<a id='deleteModelSubmit' class='btn btn-primary' href='AllCustomers?parent=-1'>Delete</a>");

        out.println("<button type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">Cancel</button>");
        out.println("</div>");
        out.println("</div>");
        out.println("</div>");
        out.println("</div>");

        out.println("</div>");
        HTML.htmlFooterSection(out);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "All Customers Servlet";
    }// </editor-fold>

}
