/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HTMLCreation;

import java.io.PrintWriter;

/**
 *
 * @author Research
 */
public class HTML {

    /**
     * Create HTML Begining
     * @param out
     */
    public static void htmlHeaderSection(PrintWriter out) {
        out.println("<!DOCTYPE html><html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\">");
        out.println("<head>");
        out.println("<meta charset=\"utf-8\"/>");
        out.println("<meta content=\"IE=edge\" http-equiv=\"X-UA-Compatible\"/>");
        out.println("<meta content=\"width=device-width, initial-scale=1\" name=\"viewport\"/>");
        out.println("<meta content=\"Order Management\" name=\"description\"/>");
        out.println("<meta content=\"Gunathilaka D.D.T.M.\" name=\"author\"/>");
        out.println("<link href=\"photo.jpg\" rel=\"icon\"/>");
        out.println("<title>Customer Management</title>");
        out.println("<link href=\"css\\bootstrap.min.css\" rel=\"stylesheet\"/>");
        out.println("<link href=\"css\\dataTables.bootstrap.min.css\" rel=\"stylesheet\"/>");
        out.println("<link href=\"css\\select.bootstrap.min.css\" rel=\"stylesheet\"/>");
        out.println("<link href=\"css\\dataTables.foundation.min.css\" rel=\"stylesheet\"/>");
        out.println("<link href=\"css\\dataTables.jqueryui.min.css\" rel=\"stylesheet\"/>");
        out.println("<link href=\"css\\bootstrap-datetimepicker-standalone.css\" rel=\"stylesheet\"/>");
        out.println("<script src=\"js\\jquery-3.1.0.min.js\"></script>");
        out.println("<script src=\"js\\bootstrap.min.js\"></script>");
        out.println("<script src=\"js\\buttons.bootstrap.min.js\"></script>");
        out.println("<script src=\"js\\buttons.html5.min.js\"></script>");
        out.println("<script src=\"js\\dataTables.bootstrap.min.js\"></script>");
        out.println("<script src=\"js\\dataTables.buttons.min.js\"></script>");
        out.println("<script src=\"js\\dataTables.select.min.js\"></script>");
        out.println("<script src=\"js\\editor.bootstrap.min.js\"></script>");
        out.println("<script src=\"js\\jquery.dataTables.min.js\"></script>");
        out.println("<script src=\"js\\dataTables.uikit.min.js\"></script>");
        out.println("<script src=\"js\\dataTables.semanticui.min.js\"></script>");
        out.println("<script src=\"js\\dataTables.select.min.js\"></script>");
        out.println("<script src=\"js\\dataTables.jqueryui.min.js\"></script>");
        out.println("<script src=\"js\\moment-with-locales.js\"></script>");
        out.println("<script src=\"js\\bootstrap-datetimepicker.min.js\"></script>");
        out.println("<script src=\"js\\validator.js\"></script>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class=\"jumbotron\">");
        out.println("<div class=\"container\">");
        out.println("<h1 class=\"display-3\">Order Management</h1>");
        out.println("</div>");
        out.println("</div>");
        out.println("<div class=\"container\">");
        out.println("<div class=\"row\">");
        out.println("<div class=\"col-md-12\">");
    }

    /**
     * Create HTML Ending
     * @param out
     */
    public static void htmlFooterSection(PrintWriter out) {
        out.println("</div>");
        out.println("</div>");
        out.println("</div>");
        out.println("<hr/>");
        out.println("<style>");
        out.println("body {");
        out.println("padding-bottom: 2rem;");
        out.println("}");
        out.println("</style>");
        out.println("<script>");
        out.println("(function () {");
        out.println("'use strict';");
        out.println("if (navigator.userAgent.match(/IEMobile\\/10\\.0/)) {");
        out.println("var msViewportStyle = document.createElement('style')");
        out.println("msViewportStyle.appendChild(");
        out.println("document.createTextNode(");
        out.println("'@-ms-viewport{width:auto!important}'");
        out.println(")");
        out.println(")");
        out.println("document.head.appendChild(msViewportStyle)");
        out.println("}");
        out.println("})();");
        out.println("</script>");
        out.println("</body>");
        out.println("</html>");
    }
}
