/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HTMLCreation;

import OrderManagementEntity.CustomerOrder;
import SessionFacadeDAO.CustomerOrderFacade;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author Research
 */
public class CheckAndValidate {

    /**
     * Create Random text len is total length
     */
    public static String genString(char first, int len) {
        String s = "";
        for (int i = 1; i < len; i++) {
            s += (char) (Math.random() * ('Z' - 'A' + 1) + 'A');
        }
        return first + s;
    }

    /**
     * Fix decimal points
     */
    public static double round(double value, int places) {
        if (places < 0) {
            throw new IllegalArgumentException();
        }

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }

    /**
     * Validate general string type parameter castings
     *
     * @param comment
     * @param amount
     * @param dueDateString
     * @return
     */
    public static boolean validateRequestParameters(String comment, String amount, String dueDateString) {
        boolean validParametres = true;

        if (comment == null || comment.trim().compareToIgnoreCase("") == 0) {
            validParametres = false;
        }
        if (amount == null || amount.trim().compareToIgnoreCase("") == 0) {
            validParametres = false;
        }
        if (dueDateString == null || dueDateString.trim().compareToIgnoreCase("") == 0) {
            validParametres = false;
        }
        return validParametres;
    }

    /**
     * Order request parameter validation
     *
     * @param amount
     * @param comment
     * @param dueDate
     * @param customerId
     * @return
     */
    public static boolean validateOrderRequestParameters(String amount, String comment, String dueDate, int customerId) {
        boolean validParametres = true;

        if (amount == null || amount.trim().compareToIgnoreCase("") == 0) {
            validParametres = false;
        }
        if (comment == null || comment.trim().compareToIgnoreCase("") == 0) {
            validParametres = false;
        }
        if (dueDate == null || dueDate.trim().compareToIgnoreCase("") == 0) {
            validParametres = false;
        }
        if (customerId < 1) {
            validParametres = false;
        }
        return validParametres;
    }

    /**
     * Check if customer has orders Enforce R3
     *
     * @param userID
     * @param customerOrderFacade
     * @return
     */
    public static String checkPendingOrdersForCustomer(Integer userID, CustomerOrderFacade customerOrderFacade) {
        int id;
        if (userID != null && userID > 0) {
            id = userID;
        } else {
            return "false";
        }
        List orders = customerOrderFacade.findAll();
        for (Iterator iterator = orders.iterator(); iterator.hasNext();) {
            CustomerOrder order = (CustomerOrder) iterator.next();
            if (order.validCustomerOrder() && order.getCustomerId().getId() == id) {
                return "true";
            }
        }
        return "false";
    }
    /**
     * Check if customer has orders Enforce R3
     *
     * @param userID
     * @param customerOrderFacade
     * @return
     */
    public static boolean checkPendingOrders(Integer userID, CustomerOrderFacade customerOrderFacade) {
        int id;
        if (userID != null && userID > 0) {
            id = userID;
        } else {
            return false;
        }
        List orders = customerOrderFacade.findAll();
        for (Iterator iterator = orders.iterator(); iterator.hasNext();) {
            CustomerOrder order = (CustomerOrder) iterator.next();
            if (order.validCustomerOrder() && order.getCustomerId().getId() == id) {
                return true;
            }
        }
        return false;
    }
}
