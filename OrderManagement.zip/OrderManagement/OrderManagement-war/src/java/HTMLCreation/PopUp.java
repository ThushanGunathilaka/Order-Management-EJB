/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HTMLCreation;

import Servlet.AllCustomers;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Research
 */
public class PopUp {

    /**
     * Add message to queue message types : success, info, warning, danger;
     * @param session
     * @param message
     * @param alertStatus
     * @param nextPage
     * @param response
     */
    public static void updateAlert(HttpSession session, String message, String alertStatus, String nextPage, HttpServletResponse response) {
        try {
            //save message in session
            List<Map<String, String>> alertMessages = new ArrayList<>();
            Map<String, String> map = new HashMap<>();
            map.put(message, alertStatus);
            alertMessages.add(map);
            session.setAttribute("AlertMessages", alertMessages);
            response.sendRedirect(nextPage);
        } catch (IOException ex) {
            Logger.getLogger(AllCustomers.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * No Redirect Add message to queue message types : success, info, warning,
     * danger;
     * @param session
     * @param message
     * @param alertStatus
     * @param response
     */
    public static void updateMessage(HttpSession session, String message, String alertStatus, HttpServletResponse response) {
        //save message in session
        List<Map<String, String>> alertMessages = new ArrayList<>();
        Map<String, String> map = new HashMap<>();
        map.put(message, alertStatus);
        alertMessages.add(map);
        session.setAttribute("AlertMessages", alertMessages);
    }

    /**
     *
     * Display Bootstrap 3 Popup
     * @param out
     * @param session
     */
    public static void displayAlert(PrintWriter out, HttpSession session) {
        try {
            List<Map<String, String>> alertMessages = (List<Map<String, String>>) session.getAttribute("AlertMessages");
            session.removeAttribute("AlertMessages");
            for (Map<String, String> element : alertMessages) {
                for (Map.Entry<String, String> entry : element.entrySet()) {
                    out.println("<div class=\"alert alert-" + entry.getValue() + "\">");
                    out.println("<a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a>");
                    out.println(entry.getKey());
                    out.println("</div>");
                }
            }
        } catch (Exception e) {
        }
    }
}
