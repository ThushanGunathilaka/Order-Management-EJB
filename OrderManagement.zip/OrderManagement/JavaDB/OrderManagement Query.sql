--
-- project: Order Management
-- author: thushan
-- !important
-- execute queries by sections
--
ALTER TABLE "APP"."CUSTOMER_ORDER" DROP CONSTRAINT "CUSTOMER_ORDER_CUSTOMER_ID_FOREIGN_KEY";
DROP TRIGGER "UPDATECUSTOMERTIMESTAMP";
DROP TABLE "APP"."CUSTOMER";
DROP TRIGGER "UPDATECUSTOMERORDERTIMESTAMP";
Drop TABLE "APP"."CUSTOMER_ORDER";
-- -----------------------------------------------------
-- Table CUSTOMER
-- -----------------------------------------------------
CREATE TABLE "APP"."CUSTOMER"
(
	"ID" INTEGER NOT NULL PRIMARY KEY GENERATED ALWAYS AS IDENTITY(START WITH 1, INCREMENT BY 1) NOT NULL,
        "CUSTOMER_ID" VARCHAR(20) NOT NULL,
	"NAME" VARCHAR(50) NOT NULL,
	"ADDRESS" VARCHAR(255) NOT NULL,
	"PHONE" VARCHAR(15) NOT NULL,
	"STATUS" VARCHAR(20) DEFAULT 'ACTIVE',
	"LAST_UPDATE" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
-- -----------------------------------------------------
-- TIMESTAMP Trigger for CUSTOMER.LAST_UPDATE
-- -----------------------------------------------------
CREATE TRIGGER "UPDATECUSTOMERTIMESTAMP"
AFTER UPDATE OF "NAME","ADDRESS","PHONE","STATUS","CUSTOMER_ID" ON "APP"."CUSTOMER"
REFERENCING OLD AS EXISTING
FOR EACH ROW MODE DB2SQL
    UPDATE "APP"."CUSTOMER" SET "LAST_UPDATE" = CURRENT_TIMESTAMP
    WHERE "ID" = EXISTING."ID"
-- -----------------------------------------------------
-- Sample data for CUSTOMER
-- -----------------------------------------------------
INSERT INTO "APP"."CUSTOMER" ("CUSTOMER_ID","NAME","ADDRESS","PHONE") VALUES 
('1000','Shore To Shore Solutions','E. P. Z. Katunayake','0112945458'),
('2000','MH Developments (pvt) Ltd','108, Flower Road, Colombo 03','0112356984'),
('4000','Cola Mineral Water','104C, Main Street, Colombo 01','0112458963');
-- -----------------------------------------------------
-- Table CUSTOMER_ORDER
-- -----------------------------------------------------
CREATE TABLE "APP"."CUSTOMER_ORDER"
(
	"ID" INTEGER NOT NULL PRIMARY KEY GENERATED ALWAYS AS IDENTITY(START WITH 1, INCREMENT BY 1) NOT NULL,
	"ORDER_ID" VARCHAR(20) NOT NULL,
	"AMOUNT" DECIMAL(15,2) NOT NULL,
	"DUE_DATE" DATE NOT NULL DEFAULT CURRENT_DATE,
	"COMMENT" VARCHAR(255) NOT NULL DEFAULT 'no comment',
	"CUSTOMER_ID" INTEGER NOT NULL,
	"STATUS" VARCHAR(20) DEFAULT 'VALID',
	"LAST_UPDATE" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
-- -----------------------------------------------------
-- TIMESTAMP Trigger for CUSTOMER_ORDER.LAST_UPDATE
-- -----------------------------------------------------
CREATE TRIGGER "UPDATECUSTOMERORDERTIMESTAMP"
AFTER UPDATE OF "ORDER_ID","AMOUNT","DUE_DATE","COMMENT","STATUS","CUSTOMER_ID" ON "APP"."CUSTOMER_ORDER"
REFERENCING OLD AS EXISTING
FOR EACH ROW MODE DB2SQL
    UPDATE "APP"."CUSTOMER_ORDER" SET "LAST_UPDATE" = CURRENT_TIMESTAMP
    WHERE "ID" = EXISTING."ID"
-- -----------------------------------------------------
-- Sample data for CUSTOMER_ORDER
-- -----------------------------------------------------
INSERT INTO "APP"."CUSTOMER_ORDER" ("ORDER_ID","AMOUNT","DUE_DATE","COMMENT","CUSTOMER_ID") VALUES 
('AB1891',45000.00,'12/22/2009','Last Delivery was cancelled due to bad packaging, need to be extra cautious this time',1),
('UT1900',15200.00,'11/10/2009','Deliver through DHL',3),
('UT1901',14500.00,'10/15/2009','no comment',3),
('CF3001',16200.00,'10/15/2009','Customer will pick the goods',2);
-- -----------------------------------------------------
-- Indexing
-- -----------------------------------------------------
CREATE INDEX "CUSTOMER_ID_INDEX" ON "APP"."CUSTOMER" ("ID" DESC);
CREATE INDEX "CUSTOMER_ORDER_ID_INDEX" ON "APP"."CUSTOMER_ORDER" ("ID" DESC);
-- -----------------------------------------------------
-- Foreign keys
-- -----------------------------------------------------
ALTER TABLE "APP"."CUSTOMER_ORDER" ADD CONSTRAINT "CUSTOMER_ORDER_CUSTOMER_ID_FOREIGN_KEY" FOREIGN KEY ("CUSTOMER_ID")
    REFERENCES "APP"."CUSTOMER" ("ID") ON UPDATE NO ACTION ON DELETE NO ACTION;